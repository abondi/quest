## Rearc Quest EC2 Terraform

 - Adds EC2 Instance running nodejs app

## Initialize terrform
terraform init

## Test terraform
terraform test

## Apply terraform 
terraform apply
