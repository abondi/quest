## Rearc Quest Q&A

Given more time, I would improve....

 - Splitting terraform into modules, i.e. modules for ecs, lbs, etc to be consumed by a quest consumer 
 - IaC subnets, vpc, etc. I had some setup from a previous setup and I would've included the entire infrastructure as needed but felt like getting the container/app running was best
 - Diagram of infrastructure for git repo

