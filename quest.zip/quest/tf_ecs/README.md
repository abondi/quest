## Rearc Quest ECS Terraform

 - Adds ECS Cluster
 - Adds ECS task definition
 - Adds ECS Service
 - Adds AWS Load balancer

## Initialize terrform
terraform init

## Test terraform
terraform test

## Apply terraform 
terraform apply
